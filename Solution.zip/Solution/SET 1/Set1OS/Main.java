import java.util.*;
public class Main{
public static void main(String[] args){
int num1=5;
int num2=8;
int num3=3;
int max=Math.max(Math.max(num1,num2),num3);
System.out.println("The sum of the largest number is: "+max);
}
}